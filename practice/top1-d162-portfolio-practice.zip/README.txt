D162 offline portfolio practice - Top1 Learning OS,13November2026
Synthetic educational model. Not real fund performance, a reserve recommendation or an offer. No LP message, paidtool, account or investment authority.

RUN
Python3standard library only:
    python3 d162_model.py --output my-d162-output
Run from this folder. The output directory is created if absent; its named result files are overwritten. No internet or personal data are used. N=1000 and seed20261110are fixed intentionally to reproduce the exercise, not a general fund configurator.

FILES
- d162_model.py: runnable model, CSV/JSON/SVG exporters and baseline self-checks.
- results/: reference six-scenario statistics/paths, baseline categorical bins and aligned SVGchart.
- practice.pdf: readable method, distributions, stress results and ten-line private defence.
- verification.json: independent24000pathchecks and threshold/bin/budget controls.
- source-notes.txt: source scope and synthetic input provenance.

BOUNDARIES
All four configurations conserve40M. All tranche investments are modeled at time0and one terminal payment at year10. Different initial-check counts do not make identical portfolios. Baseline scores are independent of payoffs, follow-onprice is doubled, no selection edge is assumed. Hindsight is NONIMPLEMENTABLE. Net scenario funds4Mfees, scales risky and idle capital90%, and charges20%only on terminal profits above40Mpaid-in. This is not a standard fund contract.
Mean/median/nearest-rankpercentiles and strict>3/<1probabilities are sample outputs, not analytic expectations. MCSE excludes model uncertainty. Exact3is not>3. Marked TVPI, realizedcash DPI and timing-based IRR are distinct; this simplified terminal multiple does not validate realmarks, cashperformance or fundpolicy.
Authored execution and rendered chart checks do not establish actual learner transfer, continuous audiovisual coverage, or overall10/10. Existing exercise/quiz/rubric unchanged. Prior model core and baseline bin data were reused, then packaged for live exercise delivery and independently verified.
