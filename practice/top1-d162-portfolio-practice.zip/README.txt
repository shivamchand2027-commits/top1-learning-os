D 162 offline portfolio practice - Top 1 Learning OS,13 November 2026
Synthetic educational model. Not real fund performance, a reserve recommendation or an offer. No LP message, paid tool, account or investment authority.

RUN
Python 3 standard library only:
    python3 d162_model.py --output my-d162-output
Run from this folder. The output directory is created if absent; its named result files are overwritten. No internet or personal data are used. N=1000 and seed 20261110 are fixed intentionally to reproduce the exercise, not a general fund configurator.

FILES
- d 162_model.py: runnable model, CSV/JSON/SVG exporters and baseline self-checks.
- results/: reference six-scenario statistics/paths, baseline categorical bins and aligned SVG chart.
- practice.pdf: readable method, distributions, stress results and ten-line private defence.
- verification.json: independent 24000  path checks and threshold/bin/budget controls.
- source-notes.txt: source scope and synthetic input provenance.

BOUNDARIES
All four configurations conserve 40 M. All tranche investments are modeled at time 0 and one terminal payment at year 10. Different initial-check counts do not make identical portfolios. Baseline scores are independent of payoffs, follow-on price is doubled, no selection edge is assumed. Hindsight is NONIMPLEMENTABLE. Net scenario funds 4 Mfees, scales risky and idle capital 90%, and charges 20% only on terminal profits above 40 Mpaid-in. This is not a standard fund contract.
Mean/median/nearest-rank percentiles and strict>3/<1 probabilities are sample outputs, not analytic expectations. MCSE excludes model uncertainty. Exact 3 is not>3. Marked TVPI, realized cash DPI and timing-based IRR are distinct; this simplified terminal multiple does not validate real marks, cash performance or fund policy.
Authored execution and rendered chart checks do not establish actual learner transfer, continuous audiovisual coverage, or overall 10/10. Existing exercise/quiz/rubric unchanged. Prior model core and baseline bin data were reused, then packaged for live exercise delivery and independently verified.
