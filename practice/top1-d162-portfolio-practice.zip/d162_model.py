"""Synthetic D162 practice model. USD millions; not an investment forecast."""
import random, statistics, math, json, csv, argparse
from pathlib import Path
from fractions import Fraction as F
SEED=20261110;N=1000

def run(tail=100,shock=False,net=False,hindsight=False):
 rng=random.Random(SEED);out={k:[]for k in 'ABCD'};deployA=[]
 for _ in range(N):
  u=[rng.random()for _ in range(40)]
  scores=[rng.random()for _ in range(40)]
  stress=rng.random()
  x=[0 if q<.55 else 2 if q<.80 else 6 if q<.92 else 25 if q<.99 else tail for q in u]
  rank=x if hindsight else scores
  c=sorted(range(24),key=lambda i:(-rank[i],i))[:6]
  d=sorted(range(40),key=lambda i:(-rank[i],i))[:10]
  factor=(0 if stress<.2 else F(5,4)) if shock else 1
  risky={'A':sum(x[:24]),'B':sum(x),'C':F(5,6)*sum(x[:24])+F(5,3)*sum(x[i] for i in c),'D':F(1,2)*sum(x)+sum(x[i] for i in d)}
  deployA.append(sum(x[:24])*factor/24)
  for k,val in risky.items():
   terminal=val*factor+(16 if k=='A'else 0)
   if net:
    terminal*=F(9,10) # 4 of 40 funds fees; all allocations scaled to 36
    terminal-=F(1,5)*max(terminal-40,0) # stipulated profit-only carry
   out[k].append(float(F(terminal)/40))
 return out,deployA

def stats(xs):
 ys=sorted(xs);p3=sum(x>3 for x in xs)/N;p1=sum(x<1 for x in xs)/N;sd=statistics.stdev(xs)
 return dict(mean=statistics.mean(xs),median=statistics.median(xs),p5=ys[math.ceil(.05*N)-1],p95=ys[math.ceil(.95*N)-1],p_gt3=p3,p_lt1=p1,sd=sd,mean_mcse=sd/math.sqrt(N),p_gt3_mcse=math.sqrt(p3*(1-p3)/N),p_lt1_mcse=math.sqrt(p1*(1-p1)/N))

SCENARIOS=[('baseline',{}),('tail50',dict(tail=50)),('tail0',dict(tail=0)),('common_shock',dict(shock=True)),('funded_fees_carry',dict(net=True)),('hindsight_only',dict(hindsight=True))]
BINS=[0,1,2,3,4,5,6,8,10,float('inf')]
LABELS=['0-<1','1-<2','2-<3','3-<4','4-<5','5-<6','6-<8','8-<10','10+']

def svg_chart(paths,folder):
 # All four panels share 0-40 percent vertical range and identical ordered bins.
 parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900"><rect width="1200" height="900" fill="white"/><text x="35" y="35" font-family="Georgia" font-size="28" fill="#251f21">D162 synthetic baseline distributions</text><text x="35" y="60" font-family="Arial" font-size="16">1000 fixed-seed paths; terminal cash / 40M commitment, not IRR or a forecast</text>']
 for panel,k in enumerate('ABCD'):
  ox=50+(panel%2)*590;oy=125+(panel//2)*360;counts=[sum(lo<=x<hi for x in paths[k])for lo,hi in zip(BINS,BINS[1:])];assert sum(counts)==N
  parts.append(f'<text x="{ox}" y="{oy-15}" font-family="Arial" font-size="22" font-weight="bold">Strategy {k} | mean {statistics.mean(paths[k]):.6f}x</text>')
  for pct in range(0,41,10):
   y=oy+240-pct*6;parts.append(f'<path d="M{ox} {y}h520" stroke="#eae9ea"/><text x="{ox-8}" y="{y+5}" text-anchor="end" font-family="Arial" font-size="13">{pct}%</text>')
  for i,count in enumerate(counts):
   x=ox+i*57+8;h=count/N*100*6;y=oy+240-h;parts.append(f'<rect x="{x}" y="{y}" width="38" height="{h}" fill="#46786c"/><text x="{x+19}" y="{y-6}" text-anchor="middle" font-family="Arial" font-size="12">{count/N*100:.1f}</text><text x="{x+19}" y="{oy+262}" text-anchor="middle" font-family="Arial" font-size="12">{LABELS[i].replace(chr(60),chr(38)+"lt;")}</text>')
 parts.append('<text x="35" y="870" font-family="Arial" font-size="15">Bins have unequal widths and equal visual spacing: categorical probabilities, not a density histogram.</text></svg>')
 (folder/'baseline-distributions.svg').write_text(''.join(parts),encoding='utf-8')

def main():
 parser=argparse.ArgumentParser(description='Offline D162 synthetic lab, no external packages or network.')
 parser.add_argument('--output',default='d162-output',help='new or existing output folder; fixed output filenames are overwritten')
 args=parser.parse_args();folder=Path(args.output);folder.mkdir(parents=True,exist_ok=True)
 scenarios={};paths={};deployed={}
 for name,kwargs in SCENARIOS:
  xs,a=run(**kwargs);paths[name]=xs;scenarios[name]={k:stats(v)for k,v in xs.items()};deployed[name]=stats([float(v)for v in a])
 for k,want in zip('ABCD',[2.83695,4.0782,3.019,3.024725]):assert abs(scenarios['baseline'][k]['mean']-want)<1e-10
 for k,want in zip('ABCD',[.350,.691,.381,.415]):assert scenarios['baseline'][k]['p_gt3']==want
 for k,want in zip('ABCD',[2.45,3.75,61/24,2.69375]):assert abs(scenarios['baseline'][k]['median']-want)<1e-10
 ev=F(55,100)*0+F(25,100)*2+F(12,100)*6+F(7,100)*25+F(1,100)*100
 assert ev==F(397,100) and 24+16==40 and 20+20==40
 summary=dict(seed=SEED,paths=N,units='USD millions; terminal multiple of40commitment',analytic_means={k:float(v)for k,v in dict(A=(24*ev+16)/40,B=ev,C=ev*F(3,4),D=ev*F(3,4)).items()},scenarios=scenarios,A_deployed_only=deployed,limits='Synthetic chosen probabilities; paired sample, not policy superiority. Hindsight is nonimplementable. MCSE excludes model error. No account, internet, real investor or learner data.')
 (folder/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 with(folder/'scenario-statistics.csv').open('w',newline='',encoding='utf-8')as f:
  fields=['scenario','strategy']+list(stats([0.0]*N));writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
  for name,ss in scenarios.items():
   for k,v in ss.items():writer.writerow(dict(scenario=name,strategy=k,**v))
 with(folder/'all-paths.csv').open('w',newline='',encoding='utf-8')as f:
  writer=csv.writer(f);writer.writerow(['scenario','path','A','B','C','D'])
  for name,xs in paths.items():
   for i in range(N):writer.writerow([name,i+1]+[xs[k][i]for k in 'ABCD'])
 with(folder/'baseline-bins.csv').open('w',newline='',encoding='utf-8')as f:
  writer=csv.writer(f);writer.writerow(['strategy','bin','count','percent'])
  for k in 'ABCD':
   for label,lo,hi in zip(LABELS,BINS,BINS[1:]):
    count=sum(lo<=x<hi for x in paths['baseline'][k]);writer.writerow([k,label,count,count/N*100])
 svg_chart(paths['baseline'],folder)
 print('D162 self-checks passed. Wrote summary,6-scenario paths/statistics,baseline bins and SVG to',folder)
if __name__=='__main__':main()
